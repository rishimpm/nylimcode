import json
import boto3
import os
import io
from PyPDF2 import PdfReader

APP_MD    = json.load(open('application_metadata_complete.json', 'r'))
REGION    = APP_MD['region']

if APP_MD['textract_for_pdf'] is not None and len(APP_MD['textract_for_pdf']) > 0 and \
    (APP_MD['textract_for_pdf'].lower() == "yes" or APP_MD['textract_for_pdf'].lower() == 'true'):
    TEXTRACT      = boto3.client('textract', region_name=REGION)
    COMPREHEND=boto3.client("comprehend")
else:
    TEXTRACT = None
    COMPREHEND = None

S3_BUCKET = APP_MD['s3_bucket_for_pdf']
S3        = boto3.client('s3', region_name=REGION)

def full_doc_extraction(file):    
    """ This is the function for the full-page retrieval technique.
        It uses the metadata collected from the retrieval system to get the original source document 
        and extract the full page content, if pdf, or entire document content (txt, json, xml files etc.)
        
        You can append functions to handle any other file format including web bages.
    """
    link=file.split('###')[0]
    if "pdf" in os.path.splitext(link)[-1]:
        files=file.split('###')
        bucket=files[0].split('/',4)[3]
        key=files[0].split('/',4)[-1]
        
        ## Read pdf file in memory
        s3 = boto3.resource('s3')
        obj = s3.Object(bucket, key)
        pdf_bytes=obj.get()['Body']
        
        ## open pdf file 
        with io.BytesIO(pdf_bytes.read()) as open_pdf_file:   
            doc = fitz.open(stream=open_pdf_file)  
        if doc.page_count>1:    
            ## Extract the page from pdf file and send to textract
            page = doc.load_page(int(files[-1]))  
            pix = page.get_pixmap(matrix=fitz.Matrix(2, 2)) 
            response = TEXTRACT.detect_document_text(
            Document={      
                 'Bytes': pix.tobytes("png", 100),
                }
            )
            blocks = response['Blocks']   

            bbox=[]
            word=[]
            for item in response['Blocks']:
                if item["BlockType"] == "WORD"  :
                    # bbox.append(item['Geometry']['BoundingBox'])
                    word.append(item["Text"])    

            result=" ".join([x for x in word])
        else:
            ## pdf has one page, send to textract
            response = TEXTRACT.detect_document_text(
            Document={      
                'S3Object': {
                'Bucket': bucket,
                'Name': key,         
                }
                }
            )
            blocks = response['Blocks']   

            bbox=[]
            word=[]
            for item in response['Blocks']:
                if item["BlockType"] == "WORD"  :
                    # bbox.append(item['Geometry']['BoundingBox'])
                    word.append(item["Text"])    

            result=" ".join([x for x in word])           
    
    elif "txt" in os.path.splitext(link)[-1]:
        files=file.split('###')
        bucket=files[0].split('/',4)[3]
        key=files[0].split('/',4)[-1]
        
        ## Read pdf file in memory
        s3 = boto3.resource('s3')
        obj = s3.Object(bucket, key)
        result=obj.get()['Body'].read().decode()
        
        
    elif "html" in os.path.splitext(link)[-1]:
        files=file.split('###')
        bucket=files[0].split('/',4)[3]
        key=files[0].split('/',4)[-1]

        ## Read pdf file in memory
        s3 = boto3.resource('s3')
        obj = s3.Object(bucket, key)
        html=obj.get()['Body'].read().decode()  
        
        part1=html.split('<head>')
        part2=part1[-1].split('</head>')
        result=part1[0]+part2[1]
      
    elif "xml" in os.path.splitext(link)[-1]:
        pass
    elif "csv" in os.path.splitext(link)[-1]:
        pass
    
    return result



def load_single_pdf(file_bytes, doc_name, S3_BUCKET=None):
    '''
        file_bytes: the bytes of PDF file
        doc_name: the document name of PDF file
        S3_BUCKET: place holder for future S3 upload
        
        the file will be saved to a temprary place
    '''
    text = None
    if S3_BUCKET is None or len(S3_BUCKET) == 0:
        try:
            os.mkdir('tmp_file')
        except:
            pass
        
        with open(f"tmp_file/{doc_name}", 'wb') as fp:
            fp.write(file_bytes)
        
        text,file_p= extract_text_cache(filepath = f"tmp_file/{doc_name}")
    else:
        s3_path=f"file_store/{doc_name}"
        S3.upload_file(doc_name, BUCKET, s3_path)
        text = textract_text(S3_BUCKET, s3_path)
    return text

def load_document(file_bytes, doc_name, param):
    s3_path=f"file_store/{doc_name}"
    file_bytes=file_bytes.read()
    S3.put_object(Body=file_bytes,Bucket= BUCKET_FOR_S3_PDF, Key=s3_path)
    time.sleep(1)
    doc_name=os.path.splitext(doc_name)[0]
    with io.BytesIO(file_bytes) as open_pdf_file:   
        doc = fitz.open(stream=open_pdf_file)
    
    if doc.page_count>1:    
        text= textract_text(BUCKET_FOR_S3_PDF, s3_path)
    else:
        ## TODO: bug - was textract_text_single, it is to extract text from image
        text= _textract_text_from_image(BUCKET_FOR_S3_PDF, s3_path)
    
    return text

def load_document_batch_summary(file_bytes, doc_name, Bucket=None): 
    if Bucket is not None:
        ## TODO: customize path to user/ai_assistant_type/{doc_name}
        s3_path=f"file_store/{doc_name}"
        S3.put_object(Body=file_bytes, Bucket= Bucket, Key=s3_path)
        time.sleep(1)
        text= textract_text(Bucket, s3_path)
    else:
        pass
    
    return text


def _textract_text_from_image(image_file_byte):
    
    response = TEXTRACT.detect_document_text(
        Document={      
            'Bytes': image_file_byte,
        }
    )
    blocks = response['Blocks']   

    bbox=[]
    word=[]
    for item in response['Blocks']:
        if item["BlockType"] == "WORD"  :
            bbox.append(item['Geometry']['BoundingBox'])
            word.append(item["Text"])    
    
    result=" ".join([x for x in word])   
    return result,bbox

def extract_text_cache(filepath, file_bytes = None):
    '''
        filepath: the location of PDF file
            I.E.: 
            filepath = 'tmp_file/chevron-sustainability-report-2020.pdf'
        OR
        file_bytes: the bytes from PDF file IO Reader
            I.E.: 
            file_io = open('tmp_file/chevron-sustainability-report-2020.pdf', 'rb')
            file_bytes = file_io.read()
    '''
    if file_bytes is None:
        local_pdf = open(filepath, mode='rb')
        pdfdoc = PdfReader(local_pdf)
        file=filepath.split('/')[-1].split('.pdf')[0]
        word_prefix=f'words/{file}'
    else:
        pdfdoc = PdfReader(io.BytesIO(file_bytes))
    
    dict_words = {}
    for p in range(len(pdfdoc.pages)):
        pageObj = pdfdoc.pages[p]
        page_text = pageObj.extract_text()
        dict_words[p] = page_text
    try:
        local_pdf.close()
    except:
        pass
    
    return dict_words

def textract_text(bucket, filepath):
    """Function to call textract asynchrounous document text extraction"""
    st.write('Extracting Text')
    ## TODO: JobTag
    response = TEXTRACT.start_document_text_detection(DocumentLocation={'S3Object': {'Bucket':bucket, 'Name':filepath}},JobTag='Employee')
    maxResults = 1000
    paginationToken = None
    finished = False
    jobId=response['JobId']
    print(jobId)
    total_words=[]   
    dict_words={}   
    
    while finished == False:
        response = None               
        if paginationToken == None:
            response = TEXTRACT.get_document_text_detection(JobId=jobId,
                                                                 MaxResults=maxResults)
        else:
            response = TEXTRACT.get_document_text_detection(JobId=jobId,
                                                                 MaxResults=maxResults,
                                                                 NextToken=paginationToken)
        
        while response['JobStatus'] != 'SUCCEEDED':
            time.sleep(2)     
            if paginationToken == None:
                response =TEXTRACT.get_document_text_detection(JobId=jobId,
                                                                 MaxResults=maxResults)
            else:
                response = TEXTRACT.get_document_text_detection(JobId=jobId,
                                                                     MaxResults=maxResults,
                                                                     NextToken=paginationToken)
        
        blocks = response['Blocks']   
        pages=set(x['Page'] for x in blocks)

        for p in pages:
            a=[]
            b=[]
            for item in response['Blocks']:
                if item["BlockType"] == "WORD" and item['Page'] ==p :
                    a.append(item['Geometry']['BoundingBox'])
                    b.append(item["Text"])
                    total_words.append(item["Text"])
            c=" ".join([x for x in b])
            try:
                dict_words[p]+= f' {c}'                
            except:
                dict_words[p]=c
        if 'NextToken' in response:
            paginationToken = response['NextToken']
        else:
            finished = True
    total_words=" ".join([x for x in total_words])
    return dict_words

def detect_entities(text):
    response = COMPREHEND.detect_entities(
                        Text=text,
                        LanguageCode='en',                        
                    )
    return response

def detect_pii(text):
    entities=COMPREHEND.detect_pii_entities(
                        Text=text,
                        LanguageCode='en'
                    )
    
    ## Comprehend extract text entities
    entities = entities['Entities']
    extracted_data = {}
    
    for entity in entities:
        entity_type = entity['Type']
        begin_offset = entity['BeginOffset']
        end_offset = entity['EndOffset']
        
        if entity_type not in extracted_data:
            extracted_data[entity_type] = []
        extracted_data[entity_type].append(text[begin_offset:end_offset])
    
    return extracted_data


