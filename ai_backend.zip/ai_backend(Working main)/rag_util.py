import json

from requests_aws4auth import AWS4Auth

APP_MD    = json.load(open('application_metadata_complete.json', 'r'))

# BUCKET_FOR_KENDRA    = APP_MD['Kendra']['bucket']
# PREFIX    = APP_MD['Kendra']['prefix']
# OS_ENDPOINT  =  APP_MD['opensearch']['domain_endpoint']
# KENDRA_ID = APP_MD['Kendra']['index']
# KENDRA_ROLE=APP_MD['Kendra']['role']

# KENDRA_S3_DATA_SOURCE_NAME=APP_MD['Kendra']['s3_data_source_name']
# KENDRA        = boto3.client('kendra', region_name=REGION)


# Vector dimension mappings of each embedding model
EMB_MODEL_DICT={"titan":1536,
                "minilmv2":384,
                "bgelarge":1024,
                "gtelarge":1024,
                "e5largev2":1024,
                "e5largemultilingual":1024,
               "gptj6b":4096,
                "cohere":1024}

# Creating unique domain names for each embedding model using the domain name prefix set in the config json file
# and a corresponding suffix of the embedding model name
EMB_MODEL_DOMAIN_NAME={"titan":f"{APP_MD['opensearch']['domain_name']}_titan",
                "minilmv2":f"{APP_MD['opensearch']['domain_name']}_minilm",
                "bgelarge":f"{APP_MD['opensearch']['domain_name']}_bgelarge",
                "gtelarge":f"{APP_MD['opensearch']['domain_name']}_gtelarge",
                "e5largev2":f"{APP_MD['opensearch']['domain_name']}_e5large",
                "e5largemultilingual":f"{APP_MD['opensearch']['domain_name']}_e5largeml",
               "gptj6b":f"{APP_MD['opensearch']['domain_name']}_gptj6b",
                       "cohere":f"{APP_MD['opensearch']['domain_name']}_cohere"}

# def query_index(query):  
#     response = KENDRA.retrieve(
#     IndexId=KENDRA_ID,
#     QueryText=query,
#     )
#     return response


# def create_os_index(param, chunks):
#     """ Create an Opensearch Index
#         It uses four mappings:
#         - embedding: chunk vector embedding
#         - passage_id: document page number of chunk
#         - passage: chunk
#         - doc_id: name of document
        
#         An opensearch undex is created per embedding model selected every subsequest indexing using that model, goes to the same opensearch index.
#         To use a new index, change teh opensearch domain name in the configuration json file.
#     """
#     st.write("Indexing...")    
#     domain_endpoint = OS_ENDPOINT
#     service = 'es'
#     credentials = boto3.Session().get_credentials()
#     awsauth = AWS4Auth(credentials.access_key, credentials.secret_key, REGION, service, session_token=credentials.token)
#     os_ = OpenSearch(
#         hosts = [{'host': OS_ENDPOINT, 'port': 443}],
#         http_auth = awsauth,
#         use_ssl = True,
#         verify_certs = True,
#         timeout=120,        
#         # http_compress = True, # enables gzip compression for request bodies
#         connection_class = RequestsHttpConnection
#     )

#     mapping = {
#       'settings': {
#         'index': {  
#           'knn': True,
#           "knn.algo_param.ef_search": round(float(param["ef_search"])),
#              "knn.space_type": "cosinesimil",
#         }
#           },

#           'mappings': {  
#             'properties': {
#               'embedding': {
#                 'type': 'knn_vector', 
#                 'dimension': EMB_MODEL_DICT[param['emb'].lower()],
#                 "method": {
#                   "name": "hnsw",       
#                   "space_type": "l2",
#                   "engine": param["engine"],
#                   "parameters": {
#                      "ef_construction": round(float(param["ef_construction"])),
#                      "m":  round(float(param["m"]))
#                    }
#                 }
#               },

#               'passage_id': {
#                 'type': 'keyword'
#               },

#               'passage': {
#                 'type': 'text'
#               },

#               'doc_id': {
#                 'type': 'keyword'
#               }
#             }
#           }
#         }

#     domain_index = f"{param['domain']}_{param['engine']}"    
    
#     if not os_.indices.exists(index=domain_index):        
#         os_.indices.create(index=domain_index, body=mapping)
#         # Verify that the index has been created
#         if os_.indices.exists(index=domain_index):
#             st.write(f"Index {domain_index} created successfully.")
#         else:
#             st.write(f"Failed to create index '{domain_index}'.")
#     else:
#         st.write(f'{domain_index} Index already exists!')
        
#     i = 1
  
#     for pages, chunk in chunks.items(): # Iterate through dict with chunk page# and content
#         chunk_id = pages.split('*')[0] # take care of multiple chunks in same page (*) is used as delimiter
#         if "titan" in param["emb"].lower():
#             prompt= {
#                 "inputText": chunk
#                 }

#             body=json.dumps(prompt)
#             modelId = param["emb_model"]
#             accept = 'application/json'
#             contentType = 'application/json'

#             response = BEDROCK.invoke_model(body=body, modelId=modelId, accept=accept,contentType=contentType)
#             response_body = json.loads(response.get('body').read())
#             embedding=response_body['embedding']
#         elif "cohere" in param["emb"].lower(): 
#             prompt= {
#                 "texts": [chunk],
#              "input_type": "search_document"
#             }
#             body=json.dumps(prompt)
#             modelId = param["emb_model"]
#             accept = "*/*"
#             contentType = 'application/json'

#             response = BEDROCK.invoke_model(body=body, modelId=modelId, accept=accept,contentType=contentType)
#             response_body = json.loads(response.get('body').read())
#             embedding=response_body['embeddings'][0]
#         else:            
#             payload = {'text_inputs': [chunk]}
#             payload = json.dumps(payload).encode('utf-8')

#             response = SAGEMAKER.invoke_endpoint(EndpointName=param["emb_model"], 
#                                                         ContentType='application/json',  
#                                                         Body=payload)

#             model_predictions = json.loads(response['Body'].read())
#             embedding = model_predictions['embedding'][0]
#         document = { 
#             'doc_id': st.session_state['file_name'], 
#             'passage_id': chunk_id,
#             'passage': chunk, 
#             'embedding': embedding}
#         try:
#             response = os_.index(index=domain_index, body=document)
#             i += 1
#             # Check the response to see if the indexing was successful
#             if response["result"] == "created":
#                 print(f"Document indexed successfully with ID: {response['_id']}")
#             else:
#                 print("Failed to index document.")
#         except RequestError as e:
#             logging.error(f"Error indexing document to index '{domain_index}': {e}")
#     return domain_index


# def kendra_index(doc_name):
#     """Create kendra s3 data source and sync files into kendra index"""
#     import time
#     response=KENDRA.list_data_sources(IndexId=KENDRA_ID)['SummaryItems']
#     data_sources=[x["Name"] for x in response if KENDRA_S3_DATA_SOURCE_NAME in x["Name"]]
#     if data_sources: # Check if s3 data source already exist and sync files
#         data_source_id=[x["Id"] for x in response if KENDRA_S3_DATA_SOURCE_NAME in x["Name"] ][0]
#         sync_response = KENDRA.start_data_source_sync_job(
#         Id = data_source_id,
#         IndexId =KENDRA_ID
#         )    
#         status=True
#         while status:
#             jobs = KENDRA.list_data_source_sync_jobs(
#                 Id = data_source_id,
#                 IndexId = KENDRA_ID
#             )
#             # For this example, there should be one job        
#             try:
#                 status = jobs["History"][0]["Status"]
#                 st.write(" Syncing data source. Status: "+status)
#                 if status != "SYNCING":
#                     status=False
#                 time.sleep(2)
#             except:
#                 time.sleep(2)
#     else: # Create a Kendra s3 data source and sync files
        
#         index_id=KENDRA_ID
#         response = KENDRA.create_data_source(
#             Name=KENDRA_S3_DATA_SOURCE_NAME,
#             IndexId=index_id,
#             Type='S3',
#             Configuration={
#                 'S3Configuration': {
#                     'BucketName': BUCKET_FOR_KENDRA,
#                     'InclusionPrefixes': [
#                         f"{PREFIX}/",
#                     ],            
#                 },
#             },     
#             RoleArn=KENDRA_ROLE, 
#             ClientToken=doc_name,                
#         )    
#         data_source_id=response['Id']
#         import time
#         status=True
#         while status:
#             # Get the details of the data source, such as the status
#             data_source_description = KENDRA.describe_data_source(
#                 Id = data_source_id,
#                 IndexId = index_id
#             )
#             # If status is not CREATING, then quit
#             status = data_source_description["Status"]
#             st.write(" Creating data source. Status: "+status)
#             time.sleep(2)
#             if status != "CREATING":
#                 status=False            
#         sync_response = KENDRA.start_data_source_sync_job(
#             Id = data_source_id,
#             IndexId = index_id
#         )    
#         status=True
#         while status:
#             jobs = KENDRA.list_data_source_sync_jobs(
#                 Id = data_source_id,
#                 IndexId = index_id
#             )
                   
#             try:
#                 status = jobs["History"][0]["Status"]
#                 st.write(" Syncing data source. Status: "+status)
#                 if status != "SYNCING":
#                     status=False
#                 time.sleep(2)
#             except:
#                 time.sleep(2)


def get_chunk_pages(page_dict,chunk):
    """
    Getting chunk page number of each chunk to use as metadata while creating the opensearch index.
    """
    token_dict={}
    length=0
    for pages in page_dict.keys():         
        length+=len(page_dict[pages].split())       
        token_dict[pages]=length
    chunk_page={}
    cumm_chunk=chunk
    for page, token_size in token_dict.items():
        while True:        
            if token_size%cumm_chunk==token_size:
                try:
                    chunk_page[round(cumm_chunk/chunk)]+=f'_{page}'
                except:
                    chunk_page[round(cumm_chunk/chunk)]=str(page)
                break
            elif token_size%cumm_chunk==0:
                try:
                    chunk_page[round(cumm_chunk/chunk)]+=f'_{page}'
                except:
                    chunk_page[round(cumm_chunk/chunk)]=str(page)
                cumm_chunk=+chunk
                break
            else:
                try:
                    chunk_page[round(cumm_chunk/chunk)]+=f'_{page}'
                except:
                    chunk_page[round(cumm_chunk/chunk)]=str(page)
                cumm_chunk+=chunk
    return chunk_page

def chunker(chunk_size, file):
    """
    Chunking by number of words, rule of thumb (1 token is ~3/5th a word).
    I did not clean punctuation marks or do any text cleaning.
    """
    chunk_size=round(chunk_size)
    result={} 
    text=' '.join(file.values())    
    words=text.split()
    n_docs = 1    
    chunk_pages=get_chunk_pages(file,chunk_size) # get page number for each chunk to use as metadata
    for i in range(0, len(words), chunk_size): # iterate through doc and create chunks not exceeding chunk size       
        chunk_words = words[i: i+chunk_size]   
        chunk = ' '.join(chunk_words)
        if chunk_pages[(int(i)//chunk_size)+1] in result.keys():
            result[f"{chunk_pages[(int(i)//chunk_size)+1]}*{str(time.time()).split('.')[-1]}"]=chunk
        else:
            result[chunk_pages[(int(i)//chunk_size)+1]]=chunk
        n_docs += 1    
    return result



def retrieval_quality_check(doc, question):
    template=f"""\n\nHuman:
Here is a document:
<document>
{doc}
</document>      

Here is a question:
Question: {question}

Review the document and check if the document is sufficient enough to answer the question completely.
If the complete answer is contained in the document respond with:
<answer>
yes
</answer>

Else respond with:
<answer>
no
</answer>

Your response should not include any preamble, just provide the answer alone in your response.\n\nAssistant:"""

    prompt={
      "prompt": template,
      "max_tokens_to_sample": 10,
      "temperature": 0.1,
      # "top_k": 250,
      # "top_p": 1,  
      #    "stop_sequences": []
    }
    prompt=json.dumps(prompt)
    output = BEDROCK.invoke_model(body=prompt,
                                    modelId='anthropic.claude-v2',  #Change model ID to a diffent anthropic model id
                                    accept="application/json", 
                                    contentType="application/json")

    output=output['body'].read().decode()
    answer=json.loads(output)['completion']
    idx1 = answer.index('<answer>')
    idx2 = answer.index('</answer>')
    response=answer[idx1 + len('<answer>') + 1: idx2]
    print(response)
    return response



def single_passage_retrieval(responses,prompt,params, handler=None):
    """
    Sends one retrieved passage a time per TopK selected to the LLM together with the user prompt.
    """
    models=["claude","llama","cohere","ai21","titan","mistral"] # mapping for the prompt template stored locally
    chosen_model=[x for x in models if x in params['model_name'].lower()][0]
    total_response=[]   
    # Assigning roles dynamically to the LLM based on persona
    persona_dict={"General":"assistant","Finance":"finanacial analyst","Insurance":"insurance analyst","Medical":"medical expert"}
    with open(f"{PARENT_TEMPLATE_PATH}/rag/{chosen_model}/prompt1.txt","r") as f:
            prompt_template=f.read()
    if "Kendra" in params["rag"]:
        for x in range(0, round(params['K'])): # provide an answer for each number of passage retrieved by the Retriever
            score = responses['ResultItems'][x]['ScoreAttributes']["ScoreConfidence"]              
            passage = responses['ResultItems'][x]['Content']
            doc_link = responses['ResultItems'][x]['DocumentURI']
            page_no="" 
            if os.path.splitext(doc_link)[-1]:
                page_no=responses['ResultItems'][x]['DocumentAttributes'][1]['Value']['LongValue']
            s3_uri=responses['ResultItems'][x]['DocumentId']
            doc_name=doc_link.split('/')[-1] if doc_link.split('/')[-1] else doc_link.split('/')[-2]
            qa_prompt =prompt_template.format(doc=passage, prompt=prompt, role=persona_dict[params['persona']])
            if "claude" in params['model_name'].lower():
                qa_prompt=f"\n\nHuman:\n{qa_prompt}\n\nAssistant:"  

            answer, in_token, out_token=query_endpoint(params, qa_prompt,handler)         
            answer1={'Answer':answer, 'Name':doc_name,'Link':doc_link, 'Score':score, 'Page': page_no, "Input Token":in_token,"Output Token":out_token}
            total_response.append(answer1)
    elif "OpenSearch" in params["rag"]:
        for response in responses:            
            score = response['_score']
            passage = response['_source']['passage']
            doc_link = f"https://{BUCKET_FOR_KENDRA}.s3.amazonaws.com/file_store/{response['_source']['doc_id']}"
            page_no = response['_source']['passage_id']   
            doc_name = response['_source']['doc_id']   
            qa_prompt =prompt_template.format(doc=passage, prompt=prompt, role=persona_dict[params['persona']])
            if "claude" in params['model_name'].lower():
                qa_prompt=f"\n\nHuman:\n{qa_prompt}\n\nAssistant:"  
            answer, in_token, out_token=query_endpoint(params, qa_prompt,handler)
            answer1={'Answer':answer, "Name":doc_name,'Link':doc_link, 'Score':score, 'Page': page_no,"Input Token":in_token,"Output Token":out_token}
            total_response.append(answer1)

    if params["memory"]:
        chat_history={"user" :prompt,
        "assistant":answer}           
        if DYNAMODB_TABLE:
            put_db(chat_history)
        else:
            st.session_state['chat_memory'].append(chat_history)            
    return total_response

def combined_passages_retrieval_technique(responses,prompt,params, handler=None):
    """
    Function implements the combined passaged retrieval technique.
    It combines topK retrieved passages into a single context and pass to the text LLM together with the user prompt.
    """
    models=["claude","llama","cohere","ai21","titan","mistral"] # mapping for the prompt template stored locally
    chosen_model=[x for x in models if x in params['model_name'].lower()][0]
    # Assigning roles dynamically to the LLM based on persona
    persona_dict={"General":"assistant","Finance":"finanacial analyst","Insurance":"insurance analyst","Medical":"medical expert"}  
    
    if "Kendra" in params["rag"]:
        score = ", ".join([x['ScoreAttributes']["ScoreConfidence"]   for x in responses['ResultItems'][:round(params['K'])]]) 
        doc_link = [x['DocumentURI'] for x in responses['ResultItems'][:round(params['K'])]]   
        page_no=", ".join([str(x['DocumentAttributes'][1]['Value']['LongValue']) for x in responses['ResultItems'][:round(params['K'])] if os.path.splitext(x['DocumentURI'])[-1]])
        doc_name=doc_name = ", ".join([x.split('/')[-1] if x.split('/')[-1] else x.split('/')[-2] for x in doc_link])
        # page_no = ", ".join([x.split('/')[-1].split('-')[-1].split('.')[0] for x in doc_link])              

        holder={}
        for x,y in enumerate(responses['ResultItems'][:round(params['K'])]):
            holder[x]={"document":y["Content"], "source":y['DocumentURI']}  
        # Reading the prompt template based on chosen model and assigning the model roles based on chosen persona
        with open(f"{PARENT_TEMPLATE_PATH}/rag/{chosen_model}/prompt1.txt","r") as f:
            prompt_template=f.read()    
        qa_prompt =prompt_template.format(doc=holder, prompt=prompt, role=persona_dict[params['persona']])
        if "claude" in params['model_name'].lower():
            qa_prompt=f"\n\nHuman:\n{qa_prompt}\n\nAssistant:"              
        answer, in_token, out_token=query_endpoint(params, qa_prompt,handler)
        answer1={'Answer':answer, 'Name':doc_name,'Link':doc_link, 'Score':score, 'Page': page_no, "Input Token":in_token,"Output Token":out_token}
        
    elif "OpenSearch" in params["rag"]:
        with open(f"{PARENT_TEMPLATE_PATH}/rag/{chosen_model}/prompt1.txt","r") as f:
                        prompt_template=f.read()
        score = ",".join([str(x['_score']) for x in responses])
        passage = [x['_source']['passage'] for x in responses]
        doc_link = f"https://{BUCKET_FOR_KENDRA}.s3.amazonaws.com/file_store/{responses[0]['_source']['doc_id']}"
        page_no = ",".join([x['_source']['passage_id'] for x in responses])
        doc_name = ", ".join([x['_source']['doc_id'] for x in responses])
        qa_prompt =prompt_template.format(doc=passage, prompt=prompt, role=persona_dict[params['persona']])
        if "claude" in params['model_name'].lower():
            qa_prompt=f"\n\nHuman:\n{qa_prompt}\n\nAssistant:"  
        answer, in_token, out_token=query_endpoint(params, qa_prompt,handler)
        answer1={'Answer':answer, "Name":doc_name,'Link':doc_link, 'Score':score, 'Page': page_no,"Input Token":in_token,"Output Token":out_token}

    # Saving chat history if enabled
    if params["memory"]:
        chat_history={"user" :prompt,
        "assistant":answer}
        # Store chat history in DynamoDb or in-memory
        if DYNAMODB_TABLE:
            put_db(chat_history)
        else:
            st.session_state['chat_memory'].append(chat_history)
    return answer1

def full_page_retrieval_technique_kendra(responses,prompt,params, handler=None):
    """
    Function implements the full-page retrieval technique.
    It gets the metatdata (page number, doc location etc) from the topK retrieved responses.
    extracts the entire page (if pdf) or entire doc (json, txt, etc.), combines all topK extraction into a single context and passes to the LLM
    together with the user prompt.
    """
    models=["claude","llama","cohere","ai21","titan","mistral"] # mapping for the prompt template stored locally
    chosen_model=[x for x in models if x in params['model_name'].lower()][0]

    # Assigning roles dynamically to the LLM based on persona
    persona_dict={"General":"assistant","Finance":"finanacial analyst","Insurance":"insurance analyst","Medical":"medical expert"}    
    score = ", ".join([x['ScoreAttributes']["ScoreConfidence"]   for x in responses['ResultItems'][:round(params['K'])]]) 
    doc_link = [x['DocumentURI'] for x in responses['ResultItems'][:round(params['K'])]]   
    doc_name=", ".join([x.split('/')[-1] for x in doc_link])
    sources = []  

    page_no=[str(x['DocumentAttributes'][1]['Value']['LongValue']) for x in responses['ResultItems'][:round(params['K'])] if os.path.splitext(x['DocumentURI'])[-1]]
    holder={}           

    from itertools import zip_longest                  
    for item1, item2 in zip_longest(doc_link, page_no, fillvalue=''):
        sources.append('###'.join([str(item1), str(item2)]))
    page_no=", ".join(page_no)   

    ## Parallely extracting the full document pages
    import multiprocessing    
    num_concurrent_invocations = len(sources)
    pool = multiprocessing.Pool(processes=num_concurrent_invocations)            
    context=pool.map(full_doc_extraction, sources)
    pool.close()
    pool.join() 

    with open(f"{PARENT_TEMPLATE_PATH}/rag/{chosen_model}/prompt1.txt","r") as f:
        prompt_template=f.read()    
    qa_prompt =prompt_template.format(doc=context, prompt=prompt, role=persona_dict[params['persona']])
    if "claude" in params['model_name'].lower():
        qa_prompt=f"\n\nHuman:\n{qa_prompt}\n\nAssistant:"  

    answer, in_token, out_token=query_endpoint(params, qa_prompt,handler)
    answer1={'Answer':answer, 'Name':doc_name,'Link':doc_link, 'Score':score, 'Page': page_no, "Input Token":in_token,"Output Token":out_token}

    if params["memory"]:
        chat_history={"user" :prompt,
        "assistant":answer}           
        if DYNAMODB_TABLE:
            put_db(chat_history)
        else:
            st.session_state['chat_memory'].append(chat_history)
    return answer1


def put_db(messages):
    """Store long term chat history in DynamoDB"""
    
    chat_item = {
        "UserId": DYNAMODB_USER,
        "messages": [messages]  # Assuming 'messages' is a list of dictionaries
    }

    # Check if the user already exists in the table
    existing_item = DYNAMODB.Table(DYNAMODB_TABLE).get_item(Key={"UserId": DYNAMODB_USER})

    # If the user exists, append new messages to the existing ones
    if "Item" in existing_item:
        existing_messages = existing_item["Item"]["messages"]
        chat_item["messages"] = existing_messages + [messages]

    response = DYNAMODB.Table(DYNAMODB_TABLE).put_item(
        Item=chat_item
    )    

def similarity_search(payload, param): 
    """ Function to run similarity search against OpenSearch index"""
    if "titan" in param["emb"].lower():
        prompt= {
            "inputText": payload
            }

        body=json.dumps(prompt)
        modelId = param["emb_model"]
        accept = 'application/json'
        contentType = 'application/json'

        response = BEDROCK.invoke_model(body=body, modelId=modelId, accept=accept,contentType=contentType)
        response_body = json.loads(response.get('body').read())
        embedding=response_body['embedding']
    elif "cohere" in param["emb"].lower(): 
            prompt= {
                "texts": [payload],
             "input_type": "search_document"
            }
            body=json.dumps(prompt)
            modelId = param["emb_model"]
            accept = 'application/json'
            contentType = 'application/json'

            response = BEDROCK.invoke_model(body=body, modelId=modelId, accept=accept,contentType=contentType)
            response_body = json.loads(response.get('body').read())
            embedding=response_body['embeddings'][0]
    else:

        payload = {'text_inputs': payload}
        payload = json.dumps(payload).encode('utf-8')

        response = SAGEMAKER.invoke_endpoint(EndpointName=param["emb_model"], 
                                                    ContentType='application/json',  
                                                    Body=payload)

        model_predictions = json.loads(response['Body'].read())
        embedding = model_predictions['embedding'][0]
    
    query = {
    'size': param["K"],
    'query': {
        "knn": {
          "embedding": {
            "vector": embedding,
            "k": param["knn"]
          }
        }
      }
    }
    

    service = 'es'
    credentials = boto3.Session().get_credentials()
    awsauth = AWS4Auth(credentials.access_key, credentials.secret_key, REGION, service, session_token=credentials.token)
    os_ = OpenSearch(
        hosts = [{'host': OS_ENDPOINT, 'port': 443}],
        http_auth = awsauth,
        use_ssl = True,
        verify_certs = True,
        timeout=120,
        # http_compress = True, # enables gzip compression for request bodies
        connection_class = RequestsHttpConnection
    )
    domain_index=f"{param['domain']}_{param['engine']}"
    response = os_.search(index=domain_index, body=query)
    hits = response['hits']['hits']    
    return hits


def split_into_sections(paragraph: str, max_words: int) -> list: 
    """
    For Batch document Summarization.
    Spliting by words, with a buffer of 50.
    """
    buffer_len=50
    sections = []
    curr_sect = []    
    # paragraph=' '.join(paragraph.values())
    for word in paragraph.split():
        if len(curr_sect) + 1 <= max_words:
            curr_sect.append(word)        
        else:            
            sections.append(' '.join(curr_sect))
            buffer=sections[-1].split()[-buffer_len:]
            curr_sect = buffer+[word]
    if curr_sect:
        buffer=sections[-1].split()[-buffer_len:]
        curr_sect=buffer+curr_sect
    sections.extend([' '.join(curr_sect) for curr_sect in ([] if not curr_sect else [curr_sect])]) 
    return sections


def sec_chunking(word_length,text, params): 
    sec_partial_summary=[]
    num_chunks=word_length//(2000 if not "mistral" in params['model_name'].lower() else 4500)
    #further chucking of initial summary and summarizing (summary of summary) 
    for i in range(num_chunks): 
        num_summary=len(text.split('##'))//num_chunks
        start = i * num_summary  
        end = (i+1) * num_summary
        if i+1==num_chunks:
            part_summary="##".join([x for x in text.split('##')[start:]])
        else:
            part_summary="##".join([x for x in text.split('##')[start:end]])
        sec_partial_summary.append(part_summary)
    return sec_partial_summary
